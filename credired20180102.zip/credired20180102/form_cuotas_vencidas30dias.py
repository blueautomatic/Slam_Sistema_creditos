# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_cuotas_vencidas30dias.ui'
#
# Created: Fri Apr  7 23:33:35 2017
#      by: PyQt5 UI code generator 5.2.1
#
# WARNING! All changes made in this file will be lost!

