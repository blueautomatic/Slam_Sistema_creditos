# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_buscar_cliente.ui'
#
# Created: Tue Oct 25 13:38:37 2016
#      by: PyQt5 UI code generator 5.2.1
#
# WARNING! All changes made in this file will be lost!

