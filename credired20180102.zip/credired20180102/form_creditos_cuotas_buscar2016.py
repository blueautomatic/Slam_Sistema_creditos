# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_creditos_cuotas_buscar2016.ui'
#
# Created: Mon Jan  2 10:48:11 2017
#      by: PyQt5 UI code generator 5.2.1
#
# WARNING! All changes made in this file will be lost!

