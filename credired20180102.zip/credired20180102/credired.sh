#!/bin/sh
cd /home/soporte/Documentos/credired20170102
python3 w_form_login.pyw 
